# ActionWM

GitHub Pages source for the **ActionWM** organization website, featuring **Acting with World Models (AWM)**, a workshop proposed for CVPR 2027.

- Target repository: [ActionWM/actionwm.github.io](https://github.com/ActionWM/actionwm.github.io)
- Target website: [actionwm.github.io](https://actionwm.github.io/)

These are the intended publishing locations. The site is live only after a successful GitHub Pages deployment.

The site is at the proposal stage. Acceptance, the exact workshop slot, and final submission policies are pending. The current roster contains six tentative speakers, eight organizers with Hang Hua first, and eight confirmed program committee members.

The current draft program has five invited-talk slots; final talk slots will be revised to accommodate the six-speaker lineup.

## Preview locally

Python 3 is the only local preview dependency:

```sh
python3 serve_preview.py
```

Open `http://127.0.0.1:8000/`; use `--port 8001` to choose another port. This server supports HTTP Range for video seeking, as does GitHub Pages. All site assets use relative paths, including when hosted at a project subpath.

## Publish to GitHub Pages

1. Create the public repository **actionwm.github.io** under the **ActionWM** organization. For an empty repository, publish this folder with:

   ```sh
   git init -b main
   git add .
   git commit -m "Add ActionWM website"
   git remote add origin https://github.com/ActionWM/actionwm.github.io.git
   git push -u origin main
   ```

2. In the repository, select **Settings → Pages → Build and deployment → Source → GitHub Actions**.
3. Run **Deploy ActionWM website to GitHub Pages** under **Actions**. Subsequent pushes to `main` deploy automatically.
4. After the `github-pages` deployment succeeds, open [https://actionwm.github.io/](https://actionwm.github.io/).

The workflow at `.github/workflows/deploy-pages.yml` uses the official GitHub Pages actions and publishes only `dist/`. No package installation, build step, third-party hosting service, or personal access token is required by the workflow.

## Update the site

| File | Contents |
| --- | --- |
| `dist/index.html` | Workshop copy, proposal status, submission plans, section structure |
| `dist/app.js` | Speaker, organizer and committee rosters, schedule, video and page interactions |
| `dist/styles.css` | Responsive layout and appearance |
| `dist/assets/` | Local fonts, portraits, robot film and stage stills |

Keep tentative and proposed labels until the corresponding information is confirmed. Check desktop and mobile layouts, navigation, submission tabs, and video stages before pushing updates. The video starts with a still when reduced motion or data saving is enabled, and includes Play/Pause controls.

Asset attribution is in `THIRD-PARTY-NOTICES.md` and `portrait-sources.json`. Retain the font license at `dist/assets/fonts/OFL.txt` and robot model license at `dist/assets/robot-model-LICENSE.txt`. Portrait rights remain with their respective owners.
