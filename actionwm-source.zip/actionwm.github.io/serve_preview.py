#!/usr/bin/env python3
"""Local static preview with HTTP byte ranges, required for reliable video seeking."""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import argparse, os, re

ROOT=Path(__file__).resolve().parent
class RangeHandler(SimpleHTTPRequestHandler):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,directory=str(ROOT/'dist'),**kwargs)
    def send_head(self):
        self._byte_range=None
        path=Path(self.translate_path(self.path))
        if path.is_dir():
            path=path/'index.html'
        if not path.is_file():
            self.send_error(404,'File not found');return None
        f=path.open('rb');size=path.stat().st_size
        value=self.headers.get('Range')
        start,end=0,max(0,size-1)
        if value:
            match=re.fullmatch(r'bytes=(\d*)-(\d*)',value.strip())
            if not match or not any(match.groups()):
                f.close();self.send_error(416);return None
            a,b=match.groups()
            if a:start=int(a);end=min(int(b) if b else size-1,size-1)
            else:start=max(0,size-int(b));end=size-1
            if start>=size or start>end:
                f.close();self.send_response(416);self.send_header('Content-Range',f'bytes */{size}');self.end_headers();return None
            self._byte_range=(start,end);f.seek(start)
        self.send_response(206 if value else 200)
        self.send_header('Content-Type',self.guess_type(str(path)))
        self.send_header('Content-Length',str(end-start+1 if size else 0))
        self.send_header('Accept-Ranges','bytes')
        self.send_header('Cache-Control','no-store')
        if value:self.send_header('Content-Range',f'bytes {start}-{end}/{size}')
        self.end_headers();return f
    def copyfile(self,source,outputfile):
        if self._byte_range is None:return super().copyfile(source,outputfile)
        left=self._byte_range[1]-self._byte_range[0]+1
        while left:
            block=source.read(min(left,65536))
            if not block:break
            try:outputfile.write(block)
            except (BrokenPipeError,ConnectionResetError):break
            left-=len(block)
    def log_message(self,fmt,*args):
        if args and str(args[1] if len(args)>1 else '') in ['404','416']:super().log_message(fmt,*args)

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--port',type=int,default=8000);a=p.parse_args()
    server=ThreadingHTTPServer(('127.0.0.1',a.port),RangeHandler)
    print(f'Local: http://127.0.0.1:{a.port}/',flush=True)
    try:server.serve_forever()
    except KeyboardInterrupt:pass
    finally:server.server_close()
