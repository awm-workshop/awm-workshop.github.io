# Acting with World Models

GitHub Pages source for the **awm-workshop** organization website (display name: **Acting with World Models**), featuring **Acting with World Models (AWM)**, a workshop proposed for CVPR 2027.

- Target repository: [awm-workshop/awm-workshop.github.io](https://github.com/awm-workshop/awm-workshop.github.io)
- Target website: [awm-workshop.github.io](https://awm-workshop.github.io/)

These are the intended publishing locations. The site is live only after a successful GitHub Pages deployment.

The site is at the proposal stage. Acceptance, the exact workshop slot, and final submission policies are pending. As of November 3, 2026, all six invited speakers have confirmed participation: William T. Freeman, Wojciech Matusik, Yilun Du, Liangliang Cao, Nicklas Hansen, and Dongfang Liu. The roster also includes eight organizers with Hang Hua first and 15 confirmed program committee members, listed alphabetically by full name.

The four-hour draft program includes six 20-minute invited-talk slots (15 minutes of presentation and 5 minutes of Q&A), a 30-minute poster session, and a 30-minute debate. Final timing remains subject to CVPR scheduling.

## Preview locally

Python 3 is the only local preview dependency:

```sh
python3 serve_preview.py
```

Open `http://127.0.0.1:8000/`; use `--port 8001` to choose another port. This server supports HTTP Range for video seeking, as does GitHub Pages. All site assets use relative paths, including when hosted at a project subpath.

## Publish to GitHub Pages

1. Create the public repository **awm-workshop.github.io** under the **awm-workshop** organization. For an empty repository, publish this folder with:

   ```sh
   git init -b main
   git add .
   git commit -m "Add AWM workshop website"
   git remote add origin https://github.com/awm-workshop/awm-workshop.github.io.git
   git push -u origin main
   ```

2. In the repository, select **Settings → Pages → Build and deployment → Source → GitHub Actions**.
3. Run **Deploy Acting with World Models to GitHub Pages** under **Actions**. Subsequent pushes to `main` deploy automatically.
4. After the `github-pages` deployment succeeds, open [https://awm-workshop.github.io/](https://awm-workshop.github.io/).

The workflow at `.github/workflows/deploy-pages.yml` uses the official GitHub Pages actions and publishes only `dist/`. No package installation, build step, third-party hosting service, or personal access token is required by the workflow.

## Update the site

| File | Contents |
| --- | --- |
| `dist/index.html` | Workshop copy, proposal status, call for papers, section structure |
| `dist/app.js` | Speaker, organizer and committee rosters, schedule, video and page interactions |
| `dist/styles.css` | Responsive layout and appearance |
| `dist/assets/` | Local fonts, portraits, robot film and stage stills |

Keep tentative and proposed labels until the corresponding information is confirmed. Check desktop and mobile layouts, navigation, submission tabs, and video stages before pushing updates. The robot animation automatically plays as a muted loop, without a visible Play/Pause control. The existing Imagine, Act, and Recover buttons seek to their stages and request playback. If the browser blocks autoplay, a stage still remains visible until playback is allowed; selecting a stage retries playback.

The typography pairs Source Serif 4 for display text with Manrope for body and interface text. Both fonts are bundled locally. Retain their SIL Open Font Licenses at `dist/assets/fonts/SourceSerif4-OFL.txt` and `dist/assets/fonts/OFL.txt`.

Asset attribution is in `THIRD-PARTY-NOTICES.md` and `portrait-sources.json`. Retain the robot model license at `dist/assets/robot-model-LICENSE.txt`. Portrait rights remain with their respective owners.
